#!/usr/bin/env bash
set -euo pipefail

# Local dev entrypoint (docker compose)
docker compose up --build
