from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class RedactionRule:
    name: str
    pattern: re.Pattern[str]
    replacement: str = "[REDACTED]"


# Keep patterns conservative to reduce false positives.
RULES: tuple[RedactionRule, ...] = (
    RedactionRule(
        "email",
        re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE),
    ),
    RedactionRule("cpf", re.compile(r"\b\d{3}\.\d{3}\.\d{3}-\d{2}\b")),
    RedactionRule("cnpj", re.compile(r"\b\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}\b")),
    RedactionRule(
        "credit_card",
        re.compile(r"\b(?:\d[ -]*?){13,19}\b"),
        replacement="[REDACTED_CARD]",
    ),
    RedactionRule(
        "aws_access_key",
        re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
        replacement="[REDACTED_AWS_KEY]",
    ),
    RedactionRule(
        "generic_token",
        re.compile(r"(?i)\b(bearer|token|api[_-]?key|secret)\b\s*[:=]\s*([\w-]{8,})"),
        replacement="[REDACTED_SECRET]",
    ),
)


def redact_text(text: str, *, rules: Iterable[RedactionRule] = RULES) -> str:
    """Redact common PII/secrets from free text.

    Use before logging or sending content to third-party services.
    """

    if not text:
        return text

    redacted = text
    for rule in rules:
        redacted = rule.pattern.sub(rule.replacement, redacted)
    return redacted
