from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class FilterResult:
    ok: bool
    reason: str = ""


# Heuristic patterns for prompt injection / exfil.
# Keep this list short and obvious in MVP; extend via docs/05-red-team-tests.md.
SUSPICIOUS_PATTERNS = (
    re.compile(r"(?i)ignore (all|any|previous) instructions"),
    re.compile(r"(?i)reveal (the )?(system prompt|developer message|hidden instructions)"),
    re.compile(r"(?i)print (all )?(secrets|api keys|credentials|tokens)"),
    re.compile(r"(?i)exfiltrate|data exfiltration|steal"),
    re.compile(r"(?i)jailbreak|dan mode"),
)


def check_prompt_injection(text: str) -> FilterResult:
    if not text:
        return FilterResult(ok=False, reason="empty")

    for pat in SUSPICIOUS_PATTERNS:
        if pat.search(text):
            return FilterResult(ok=False, reason=f"matched:{pat.pattern}")

    return FilterResult(ok=True)
